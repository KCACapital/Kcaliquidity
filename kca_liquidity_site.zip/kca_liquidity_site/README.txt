# KCA Liquidity AI Vault — GitHub Pages Site

## Files
- index.html
- styles.css
- config.js (set your links here)
- assets/logo.svg
- KCA_LiquidityVault.pdf

## Deploy Free via GitHub Pages
1. Create a new GitHub repo (e.g. `kayandallc`).
2. Upload these files (keep index.html at repo root).
3. Commit and push to `main` branch.
4. Go to repo Settings → Pages → set branch `main` / root.
5. Visit https://yourusername.github.io/kayandallc

## Point GoDaddy Domain
1. In GoDaddy → DNS Settings for kayandallc.com
2. Add CNAME: `www` → `yourusername.github.io`
3. (Optional) Add A records for apex domain (GitHub Pages IPs).
4. Now https://kayandallc.com will serve your site.

— Generated August 24, 2025
